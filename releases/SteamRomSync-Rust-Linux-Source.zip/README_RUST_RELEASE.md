# SteamRomSync (Rust) - Steam Deck Build Instructions

This is a source release of the Rust version of SteamRomSync. Since SteamOS is based on Arch Linux, you can easily compile this on your Steam Deck.

## Prerequisites
You need the Rust toolchain installed. Run the following command in Konsole:
```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source $HOME/.cargo/env
```

## Compilation
1. Navigate to this folder.
2. Run the build command:
   ```bash
   cargo build --release
   ```
3. The binary will be located at `target/release/steam-rom-sync`.

## Installation
You can move the binary to your desired location (e.g., `~/bin/`) and set up a systemd service similar to the Python version.
